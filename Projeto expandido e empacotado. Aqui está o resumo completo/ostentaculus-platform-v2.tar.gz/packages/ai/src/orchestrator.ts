import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

/**
 * OSTENTACULUS MASTER ORCHESTRATOR
 * Routes requests to the correct subagent based on intent classification.
 * 22 subagents + 5 skills = full OPB digital department.
 */

// ── Tier 0: Orchestration ────────────────────────────────────────────────────
export { planEditorialCalendar } from "./marketing/chief-of-staff";

// ── Tier 1: Content Factory ──────────────────────────────────────────────────
export { analyzeAudience } from "./marketing/audience-intelligence";
export { generateVideoBrief } from "./marketing/storytelling";
export { generateDistribution } from "./marketing/distribution-seo";
export { generateCinematicScript } from "./agents/scriptwriter";
export { generateNeuroHook } from "./agents/neuro-hook";

// ── Tier 2: Growth & Conversion ──────────────────────────────────────────────
export { planTrafficCampaign } from "./agents/growth-quartet";
export { runSalesFollowUp } from "./agents/growth-quartet";
export { optimizeConversionPage } from "./agents/growth-quartet";
export { analyzeRevenue } from "./agents/growth-quartet";

// ── Tier 3: Data & Intelligence ──────────────────────────────────────────────
export { indexTourismDocuments, answerTourismQuestion } from "./tourism-rag";
export { analyzePosData } from "./agents/pos-analytics";
export { analyzeCompetitors } from "./agents/competitor-intel";
export { calculatePerformanceFee } from "./agents/performance-fee";

// ── Tier 4: Client Experience ────────────────────────────────────────────────
export { composeConciergeMessage } from "./concierge";
export { generateWeeklyReport } from "./report";
export { generateOnboardingPlan } from "./agents/client-lifecycle";
export { generateRetentionStrategy } from "./agents/client-lifecycle";

// ── Tier 5: Operations & Compliance ─────────────────────────────────────────
export { generateDocumentaryPipeline } from "./agents/documentary-pipeline";
export { auditRgpdCompliance } from "./agents/ops-compliance";
export { runSecurityAudit } from "./agents/ops-compliance";
export { reviewCode, ultraReviewCode } from "./agents/ops-compliance";

// ── Skills ───────────────────────────────────────────────────────────────────
export { createSkill } from "./skills/skill-creator";
export { withSuperpowers, withAdversarialSuperpowers } from "./skills/superpowers";
export { getShitDone } from "./skills/get-shit-done";
export { generateFrontendComponent, DESIGN_TOKENS } from "./skills/frontend-design";
export { generatePlaywrightScript, generatePlaywrightConfig } from "./skills/playwright-mcp";

// ── Intent Router ─────────────────────────────────────────────────────────────
const client = new Anthropic();

const ROUTER_SYSTEM = `You are the Ostentaculus intent router. Given a natural language request, classify it into one of 22 agent functions. Return ONLY the function name — no explanation.

Available functions:
planEditorialCalendar, analyzeAudience, generateVideoBrief, generateDistribution,
generateCinematicScript, generateNeuroHook, planTrafficCampaign, runSalesFollowUp,
optimizeConversionPage, analyzeRevenue, indexTourismDocuments, answerTourismQuestion,
analyzePosData, analyzeCompetitors, calculatePerformanceFee, composeConciergeMessage,
generateWeeklyReport, generateOnboardingPlan, generateRetentionStrategy,
generateDocumentaryPipeline, auditRgpdCompliance, runSecurityAudit, reviewCode, ultraReviewCode,
createSkill, withSuperpowers, getShitDone, generateFrontendComponent, generatePlaywrightScript`;

/**
 * Routes a natural language request to the correct agent function name.
 * Use this to build dynamic dispatch in API routes or n8n workflows.
 */
export async function routeToAgent(request: string): Promise<string> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 50,
    system: ROUTER_SYSTEM,
    messages: [{ role: "user", content: request }],
  });

  return res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("")
    .trim();
}
