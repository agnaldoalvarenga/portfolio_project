import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

/**
 * SKILL: frontend-design
 * Generates production-ready React/Next.js components following the
 * Ostentaculus design system: cinema dark (#111A2E), champagne gold (#D4AF37),
 * Mediterranean teal (#1D9E75), serif headings, sans body.
 */

const client = new Anthropic();

const DESIGN_TOKENS = {
  colors: {
    navy: "#111A2E",
    gold: "#D4AF37",
    teal: "#1D9E75",
    cream: "#F5F0E8",
  },
  fonts: {
    display: "Playfair Display, Georgia, serif",
    body: "Inter, system-ui, sans-serif",
    mono: "JetBrains Mono, monospace",
  },
  shadows: {
    card: "0 4px 24px rgba(0,0,0,0.4)",
    glow: "0 0 32px rgba(212,175,55,0.15)",
  },
} as const;

const SYSTEM = `You are the Ostentaculus Frontend Design Agent. You generate production-ready React components using Next.js App Router, TypeScript strict, and Tailwind CSS.

Design system (non-negotiable):
- Background: #111A2E (Executive Navy)
- Primary accent: #D4AF37 (Champagne Gold) — for CTAs, highlights, borders
- Data accent: #1D9E75 (Mediterranean Teal) — for metrics, live data, tracking
- Typography: Playfair Display (serif) for headings; Inter (sans) for body
- No rounded corners on hero elements — sharp corners signal precision
- Framer Motion for all transitions (scale, fade, stagger)
- Fully responsive: mobile-first, ultra-wide support (max-w-8xl)
- Zero AI branding visible to end users
- Semantic HTML, ARIA labels, keyboard navigation

Output: complete, production-ready .tsx file. No TODOs in critical paths. Import paths use @/ alias.`;

const SCHEMA = {
  type: "object",
  properties: {
    componentName: { type: "string" },
    filePath: { type: "string" },
    code: { type: "string" },
    tailwindExtensions: { type: "string" }, // any tailwind.config additions needed
    dependencies: { type: "array", items: { type: "string" } },
    accessibilityNotes: { type: "string" },
  },
  required: ["componentName", "filePath", "code", "tailwindExtensions", "dependencies", "accessibilityNotes"],
  additionalProperties: false,
} as const;

export interface FrontendComponent {
  componentName: string;
  filePath: string;
  code: string;
  tailwindExtensions: string;
  dependencies: string[];
  accessibilityNotes: string;
}

export async function generateFrontendComponent(input: {
  description: string;
  section?: string; // hero | pricing | vectors | testimonials | nav | footer
  locale?: string;
  interactivity?: string; // what user interactions to support
}): Promise<FrontendComponent> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 4000,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Component description: ${input.description}\n` +
        `Section: ${input.section ?? "(standalone)"}\n` +
        `Locale: ${input.locale ?? "es"}\n` +
        `Interactivity: ${input.interactivity ?? "(standard hover states)"}\n\n` +
        `Design tokens available:\n${JSON.stringify(DESIGN_TOKENS, null, 2)}\n\n` +
        `Generate a production-ready .tsx component. No placeholders in critical paths.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return JSON.parse(text) as FrontendComponent;
}

export { DESIGN_TOKENS };
