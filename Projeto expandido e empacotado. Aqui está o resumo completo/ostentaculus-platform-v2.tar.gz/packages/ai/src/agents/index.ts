/**
 * OSTENTACULUS — 22-SUBAGENT ARCHITECTURE
 *
 * TIER 0 — ORCHESTRATION (1)
 *   01. ChiefOfStaff          → already in marketing/chief-of-staff.ts (editorial calendar)
 *
 * TIER 1 — CONTENT FACTORY (5)
 *   02. AudienceIntelligence  → marketing/audience-intelligence.ts
 *   03. Storytelling          → marketing/storytelling.ts
 *   04. DistributionSeo       → marketing/distribution-seo.ts
 *   05. ScriptwriterAgent     → agents/scriptwriter.ts       [NEW]
 *   06. NeuroHookAgent        → agents/neuro-hook.ts         [NEW]
 *
 * TIER 2 — GROWTH & CONVERSION (4)
 *   07. TrafficAgent          → agents/traffic.ts            [NEW]
 *   08. SalesAgent            → agents/sales.ts              [NEW]
 *   09. ConversionAgent       → agents/conversion.ts         [NEW]
 *   10. RevenueAgent          → agents/revenue.ts            [NEW]
 *
 * TIER 3 — DATA & INTELLIGENCE (4)
 *   11. TourismRag            → tourism-rag.ts
 *   12. PosAnalyticsAgent     → agents/pos-analytics.ts      [NEW]
 *   13. CompetitorIntelAgent  → agents/competitor-intel.ts   [NEW]
 *   14. PerformanceFeeAgent   → agents/performance-fee.ts    [NEW]
 *
 * TIER 4 — CLIENT EXPERIENCE (4)
 *   15. ConciergeAgent        → concierge.ts
 *   16. WeeklyReportAgent     → report.ts
 *   17. OnboardingAgent       → agents/onboarding.ts         [NEW]
 *   18. RetentionAgent        → agents/retention.ts          [NEW]
 *
 * TIER 5 — OPERATIONS & COMPLIANCE (4)
 *   19. DocumentaryPipeline   → agents/documentary-pipeline.ts [NEW]
 *   20. RgpdComplianceAgent   → agents/rgpd-compliance.ts    [NEW]
 *   21. SecurityAuditAgent    → agents/security-audit.ts     [NEW]
 *   22. ReviewAgent           → agents/review.ts             [NEW — /review & /ultrareview skill]
 *
 * SKILLS (5)
 *   skill-creator             → skills/skill-creator.ts
 *   superpowers               → skills/superpowers.ts
 *   get-shit-done             → skills/get-shit-done.ts
 *   frontend-design           → skills/frontend-design.ts
 *   playwright-mcp            → skills/playwright-mcp.ts
 */

// ── Re-exports: existing agents ─────────────────────────────────────────────
export { planEditorialCalendar } from "../marketing/chief-of-staff";
export { analyzeAudience } from "../marketing/audience-intelligence";
export { generateVideoBrief } from "../marketing/storytelling";
export { generateDistribution } from "../marketing/distribution-seo";
export { composeConciergeMessage } from "../concierge";
export { generateWeeklyReport } from "../report";
export { indexTourismDocuments, answerTourismQuestion } from "../tourism-rag";

// ── Re-exports: new agents ───────────────────────────────────────────────────
export { generateCinematicScript } from "./scriptwriter";
export { generateNeuroHook } from "./neuro-hook";
export { planTrafficCampaign } from "./traffic";
export { runSalesFollowUp } from "./sales";
export { optimizeConversionPage } from "./conversion";
export { analyzeRevenue } from "./revenue";
export { analyzePosData } from "./pos-analytics";
export { analyzeCompetitors } from "./competitor-intel";
export { calculatePerformanceFee } from "./performance-fee";
export { generateOnboardingPlan } from "./onboarding";
export { generateRetentionStrategy } from "./retention";
export { generateDocumentaryPipeline } from "./documentary-pipeline";
export { auditRgpdCompliance } from "./rgpd-compliance";
export { runSecurityAudit } from "./security-audit";
export { reviewCode, ultraReviewCode } from "./review";
