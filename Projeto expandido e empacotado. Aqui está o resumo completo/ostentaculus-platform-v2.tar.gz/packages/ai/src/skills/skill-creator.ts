import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

/**
 * SKILL: skill-creator
 * Meta-skill. Creates, optimizes, and benchmarks other AI skills/agents.
 * Inspired by: Anthropic skill-creator methodology.
 */

const SYSTEM = `You are the Ostentaculus Skill Creator — a meta-agent that designs, refines, and benchmarks other AI skills. Given a task description, you produce:
1. A structured SKILL.md specification (name, description, triggers, anti-triggers, examples).
2. The TypeScript implementation skeleton with the correct Anthropic SDK patterns.
3. A test suite outline (happy path, edge cases, security cases).
4. A trigger description optimized for agent routing systems.

Apply the Anthropic prompt engineering best practices: clear persona, explicit output schema, chain-of-thought in thinking mode, concrete examples. Never produce vague descriptions — every skill must be unambiguously triggerable.`;

const SCHEMA = {
  type: "object",
  properties: {
    skillName: { type: "string" },
    skillMd: { type: "string" },
    typescriptSkeleton: { type: "string" },
    triggerDescription: { type: "string" },
    antiTriggers: { type: "array", items: { type: "string" } },
    testOutline: { type: "array", items: { type: "string" } },
  },
  required: ["skillName", "skillMd", "typescriptSkeleton", "triggerDescription", "antiTriggers", "testOutline"],
  additionalProperties: false,
} as const;

export interface SkillSpec {
  skillName: string;
  skillMd: string;
  typescriptSkeleton: string;
  triggerDescription: string;
  antiTriggers: string[];
  testOutline: string[];
}

export async function createSkill(input: {
  taskDescription: string;
  targetAgent?: string; // which of the 22 agents this skill augments
  examples?: string[];
  locale?: string;
}): Promise<SkillSpec> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 3000,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Task to encapsulate as a skill: ${input.taskDescription}\n` +
        `Target agent: ${input.targetAgent ?? "(standalone)"}\n` +
        `Examples:\n${input.examples?.map((e) => `- ${e}`).join("\n") ?? "(none)"}\n` +
        `Locale: ${input.locale ?? "en"}\n\n` +
        `Produce the complete SKILL.md spec, TypeScript skeleton, trigger description, and test outline.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return JSON.parse(text) as SkillSpec;
}
