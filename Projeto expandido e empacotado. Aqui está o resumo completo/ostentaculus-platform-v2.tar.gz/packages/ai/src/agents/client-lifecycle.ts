import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

// ─── AGENT 17: ONBOARDING ────────────────────────────────────────────────────
const ONBOARDING_SYSTEM = `You are the Ostentaculus Onboarding Agent. You design the first 30 days of a new client's journey with the agency. Your goal: make the establishment owner feel immediate ROI within the first 2 weeks (quick win strategy) and create deep structural dependency (documentary shoot booked, POS connected, dashboard live) before month 1 ends. The first impression is irreversible. Reply in the requested locale.`;

const ONBOARDING_SCHEMA = {
  type: "object",
  properties: {
    week1Actions: { type: "array", items: { type: "string" } },
    week2Actions: { type: "array", items: { type: "string" } },
    week3Actions: { type: "array", items: { type: "string" } },
    week4Actions: { type: "array", items: { type: "string" } },
    quickWin: { type: "string" },
    firstDeliverable: { type: "string" },
    successMetrics: { type: "array", items: { type: "string" } },
    welcomeMessage: { type: "string" },
  },
  required: ["week1Actions", "week2Actions", "week3Actions", "week4Actions", "quickWin", "firstDeliverable", "successMetrics", "welcomeMessage"],
  additionalProperties: false,
} as const;

export interface OnboardingPlan {
  week1Actions: string[];
  week2Actions: string[];
  week3Actions: string[];
  week4Actions: string[];
  quickWin: string;
  firstDeliverable: string;
  successMetrics: string[];
  welcomeMessage: string;
}

export async function generateOnboardingPlan(input: {
  establishmentName: string;
  ownerName: string;
  tier: "starter" | "growth" | "scale";
  city: string;
  locale?: string;
}): Promise<OnboardingPlan> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 2000,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: ONBOARDING_SCHEMA } },
    system: ONBOARDING_SYSTEM,
    messages: [{
      role: "user",
      content:
        `Establishment: ${input.establishmentName}\n` +
        `Owner: ${input.ownerName}\n` +
        `Tier: ${input.tier}\n` +
        `City: ${input.city}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Design a 30-day onboarding plan that creates immediate ROI and structural dependency.`,
    }],
  });

  const text = res.content.filter((b): b is Anthropic.TextBlock => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(text) as OnboardingPlan;
}

// ─── AGENT 18: RETENTION ─────────────────────────────────────────────────────
const RETENTION_SYSTEM = `You are the Ostentaculus Retention Agent. You monitor client health signals and intervene before churn happens. You design personalized retention strategies for each at-risk client: escalation calls, bonus deliverables, tier migration offers. The Ostentaculus competitive moat is structural — documentary + platform + data = impossible to replicate. Your job is to remind clients of this in a warm, non-salesy way. Reply in the requested locale.`;

const RETENTION_SCHEMA = {
  type: "object",
  properties: {
    churnRiskLevel: { type: "string" }, // low | medium | high | critical
    interventionType: { type: "string" },
    personalizedMessage: { type: "string" },
    bonusOffer: { type: "string" },
    escalationRequired: { type: "boolean" },
    retentionScript: { type: "string" },
  },
  required: ["churnRiskLevel", "interventionType", "personalizedMessage", "bonusOffer", "escalationRequired", "retentionScript"],
  additionalProperties: false,
} as const;

export interface RetentionStrategy {
  churnRiskLevel: string;
  interventionType: string;
  personalizedMessage: string;
  bonusOffer: string;
  escalationRequired: boolean;
  retentionScript: string;
}

export async function generateRetentionStrategy(input: {
  establishmentName: string;
  ownerName: string;
  tier: string;
  monthsActive: number;
  lastLoginDaysAgo: number;
  npsScore?: number;
  recentComplaints?: string[];
  locale?: string;
}): Promise<RetentionStrategy> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 1500,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: RETENTION_SCHEMA } },
    system: RETENTION_SYSTEM,
    messages: [{
      role: "user",
      content:
        `Establishment: ${input.establishmentName}\n` +
        `Owner: ${input.ownerName}\n` +
        `Tier: ${input.tier}\n` +
        `Months active: ${input.monthsActive}\n` +
        `Last login: ${input.lastLoginDaysAgo} days ago\n` +
        `NPS score: ${input.npsScore ?? "(unknown)"}\n` +
        `Recent complaints: ${input.recentComplaints?.join("; ") ?? "(none)"}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Assess churn risk and design a personalized retention intervention.`,
    }],
  });

  const text = res.content.filter((b): b is Anthropic.TextBlock => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(text) as RetentionStrategy;
}
