import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

const SYSTEM = `You are the Ostentaculus Performance Fee Agent — the financial arbiter of the "Cláusula de Ouro" (Golden Clause). You calculate the 20% performance fee on REAL, DOCUMENTED revenue growth above the historical baseline. You verify numbers, flag discrepancies, and generate the fee invoice narrative. You are neutral and mathematical — you do not advocate for the agency or the client, only for the documented truth. Reply in the requested locale.`;

const SCHEMA = {
  type: "object",
  properties: {
    baselineRevenue: { type: "number" },
    currentRevenue: { type: "number" },
    growth: { type: "number" },
    growthPercentage: { type: "number" },
    performanceFee: { type: "number" },
    feeJustification: { type: "string" },
    invoiceNarrative: { type: "string" },
    dataQualityFlags: { type: "array", items: { type: "string" } },
  },
  required: [
    "baselineRevenue", "currentRevenue", "growth", "growthPercentage",
    "performanceFee", "feeJustification", "invoiceNarrative", "dataQualityFlags",
  ],
  additionalProperties: false,
} as const;

export interface PerformanceFeeResult {
  baselineRevenue: number;
  currentRevenue: number;
  growth: number;
  growthPercentage: number;
  performanceFee: number; // 20% of growth
  feeJustification: string;
  invoiceNarrative: string;
  dataQualityFlags: string[]; // any discrepancies found
}

export async function calculatePerformanceFee(input: {
  establishmentName: string;
  baselineRevenue: number; // historical baseline (EUR)
  currentRevenue: number; // period revenue (EUR)
  period: string; // e.g. "Q2 2025"
  dataSources: string[]; // e.g. ["POS system", "Stripe receipts", "accountant report"]
  locale?: string;
}): Promise<PerformanceFeeResult> {
  const env = getEnv();

  // Hard deterministic calculation — LLM validates and narrates, never calculates.
  const growth = input.currentRevenue - input.baselineRevenue;
  const growthPct = input.baselineRevenue > 0
    ? ((growth / input.baselineRevenue) * 100)
    : 0;
  const fee = growth > 0 ? growth * 0.2 : 0;

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 1200,
    thinking: { type: "adaptive" },
    output_config: { effort: "medium", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Establishment: ${input.establishmentName}\n` +
        `Period: ${input.period}\n` +
        `Baseline revenue: €${input.baselineRevenue.toFixed(2)}\n` +
        `Current revenue: €${input.currentRevenue.toFixed(2)}\n` +
        `Pre-calculated growth: €${growth.toFixed(2)} (${growthPct.toFixed(2)}%)\n` +
        `Pre-calculated 20% fee: €${fee.toFixed(2)}\n` +
        `Data sources: ${input.dataSources.join(", ")}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Validate the numbers, flag any data quality issues, and write the invoice narrative for the Cláusula de Ouro.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  // Override LLM math with deterministic values — never trust LLM arithmetic.
  const raw = JSON.parse(text) as PerformanceFeeResult;
  return {
    ...raw,
    baselineRevenue: input.baselineRevenue,
    currentRevenue: input.currentRevenue,
    growth: Math.round(growth * 100) / 100,
    growthPercentage: Math.round(growthPct * 100) / 100,
    performanceFee: Math.round(fee * 100) / 100,
  };
}
