/**
 * OSTENTACULUS — 5 SKILLS
 *
 * 1. skill-creator    → meta-skill, cria e otimiza outros skills
 * 2. superpowers      → modo de raciocínio profundo + adversarial self-critique
 * 3. get-shit-done    → execução zero-fricção de tarefas operacionais
 * 4. frontend-design  → geração de componentes React com design system Ostentaculus
 * 5. playwright-mcp   → testes E2E e automação de browser
 */

export { createSkill } from "./skill-creator";
export { withSuperpowers, withAdversarialSuperpowers } from "./superpowers";
export { getShitDone } from "./get-shit-done";
export { generateFrontendComponent, DESIGN_TOKENS } from "./frontend-design";
export { generatePlaywrightScript, generatePlaywrightConfig } from "./playwright-mcp";
