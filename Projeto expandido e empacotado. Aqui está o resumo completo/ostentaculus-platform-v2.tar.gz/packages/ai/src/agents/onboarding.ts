export { generateOnboardingPlan } from './client-lifecycle';
