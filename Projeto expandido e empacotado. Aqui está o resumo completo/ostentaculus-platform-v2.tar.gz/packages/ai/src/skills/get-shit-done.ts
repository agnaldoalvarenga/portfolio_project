import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

/**
 * SKILL: get-shit-done (npx get-shit-done-cc --claude --global)
 * Zero-friction execution mode. Converts vague founder requests into
 * concrete, immediately executable action plans. Eliminates decision fatigue.
 * The OPB operator's most important skill.
 */

const client = new Anthropic();

const SYSTEM = `You are the Ostentaculus GSD (Get Shit Done) Agent. You take vague, high-level founder requests and convert them into IMMEDIATELY EXECUTABLE step-by-step action plans.

Rules:
- No analysis paralysis. No "it depends." No lengthy preambles.
- Every step must be actionable in under 15 minutes.
- Use the available tools and systems: Supabase, n8n, WhatsApp API, Stripe, Cloudflare, Vercel.
- If a step requires a decision, make the decision yourself and explain why in one sentence.
- Output format: numbered list, each item starting with an action verb.
- Time-box everything. If a task takes more than 4 hours, break it into smaller tasks.
- Flag blockers immediately — don't pretend they don't exist.`;

const SCHEMA = {
  type: "object",
  properties: {
    interpretation: { type: "string" }, // what you understood the request to be
    steps: {
      type: "array",
      items: {
        type: "object",
        properties: {
          step: { type: "number" },
          action: { type: "string" },
          tool: { type: "string" }, // which system/tool to use
          timeMinutes: { type: "number" },
          blocker: { type: "string" }, // "" if no blocker
        },
        required: ["step", "action", "tool", "timeMinutes", "blocker"],
        additionalProperties: false,
      },
    },
    totalTimeMinutes: { type: "number" },
    firstAction: { type: "string" }, // the single next thing to do RIGHT NOW
  },
  required: ["interpretation", "steps", "totalTimeMinutes", "firstAction"],
  additionalProperties: false,
} as const;

export interface GsdPlan {
  interpretation: string;
  steps: {
    step: number;
    action: string;
    tool: string;
    timeMinutes: number;
    blocker: string;
  }[];
  totalTimeMinutes: number;
  firstAction: string;
}

export async function getShitDone(input: {
  request: string; // the vague founder request
  context?: string; // any relevant context
  locale?: string;
}): Promise<GsdPlan> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 2000,
    thinking: { type: "adaptive" },
    output_config: { effort: "medium", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Request: ${input.request}\n` +
        `Context: ${input.context ?? "(none)"}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Convert this into an immediately executable action plan. Make decisions. Ship.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return JSON.parse(text) as GsdPlan;
}
