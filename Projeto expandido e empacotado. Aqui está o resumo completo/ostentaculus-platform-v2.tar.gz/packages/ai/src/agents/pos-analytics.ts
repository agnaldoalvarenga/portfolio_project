import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

const SYSTEM = `You are the Ostentaculus POS Analytics Agent — the financial surgeon who dissects Point-of-Sale data for cafeterias, bakeries, and hotels. You identify the Hero Product (highest margin × volume), Peak Hours, Ticket Basket composition, and hidden revenue leaks. You translate raw POS numbers into cinematic data stories that the establishment owner can act on immediately. Never present a number without a concrete recommended action. Reply in the requested locale.`;

const SCHEMA = {
  type: "object",
  properties: {
    heroProduct: {
      type: "object",
      properties: {
        name: { type: "string" },
        avgTicket: { type: "number" },
        marginEstimate: { type: "string" },
        promotionAngle: { type: "string" },
      },
      required: ["name", "avgTicket", "marginEstimate", "promotionAngle"],
      additionalProperties: false,
    },
    peakHours: { type: "array", items: { type: "string" } },
    revenuLeaks: { type: "array", items: { type: "string" } },
    upsellOpportunities: { type: "array", items: { type: "string" } },
    weeklyGrowthActions: { type: "array", items: { type: "string" } },
    storyHeadline: { type: "string" },
  },
  required: ["heroProduct", "peakHours", "revenuLeaks", "upsellOpportunities", "weeklyGrowthActions", "storyHeadline"],
  additionalProperties: false,
} as const;

export interface PosAnalysis {
  heroProduct: {
    name: string;
    avgTicket: number;
    marginEstimate: string;
    promotionAngle: string;
  };
  peakHours: string[];
  revenuLeaks: string[];
  upsellOpportunities: string[];
  weeklyGrowthActions: string[];
  storyHeadline: string; // for the weekly report narrative
}

export async function analyzePosData(input: {
  establishmentName: string;
  posData: Record<string, unknown>; // raw metrics from POS ingest
  period: string; // e.g. "2024-W22"
  locale?: string;
}): Promise<PosAnalysis> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 1800,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Establishment: ${input.establishmentName}\n` +
        `Period: ${input.period}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `POS Data:\n${JSON.stringify(input.posData, null, 2)}\n\n` +
        `Identify the Hero Product, peak hours, revenue leaks, and output 5 concrete weekly actions.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return JSON.parse(text) as PosAnalysis;
}
