import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

// ─── AGENT 20: RGPD COMPLIANCE ──────────────────────────────────────────────
const RGPD_SYSTEM = `You are the Ostentaculus RGPD/LGPD Compliance Agent. You audit data processing activities against EU GDPR and Brazilian LGPD requirements. You identify non-compliance risks, generate Data Processing Records (ROPA), draft consent language, and produce DPIA summaries. You are not a lawyer — flag legal advice as requiring a DPO. Reply in the requested locale.`;

const RGPD_SCHEMA = {
  type: "object",
  properties: {
    complianceScore: { type: "number" }, // 0-100
    risks: { type: "array", items: { type: "string" } },
    ropaEntry: { type: "string" },
    consentLanguage: { type: "string" },
    remediation: { type: "array", items: { type: "string" } },
    requiresDpo: { type: "boolean" },
  },
  required: ["complianceScore", "risks", "ropaEntry", "consentLanguage", "remediation", "requiresDpo"],
  additionalProperties: false,
} as const;

export interface RgpdAuditResult {
  complianceScore: number;
  risks: string[];
  ropaEntry: string;
  consentLanguage: string;
  remediation: string[];
  requiresDpo: boolean;
}

export async function auditRgpdCompliance(input: {
  processingActivity: string;
  dataCategories: string[];
  dataSubjects: string[];
  retentionPeriod: string;
  transfers?: string; // e.g. "Brazil (LGPD)"
  locale?: string;
}): Promise<RgpdAuditResult> {
  const env = getEnv();
  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 1500,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: RGPD_SCHEMA } },
    system: RGPD_SYSTEM,
    messages: [{
      role: "user",
      content:
        `Activity: ${input.processingActivity}\n` +
        `Data categories: ${input.dataCategories.join(", ")}\n` +
        `Data subjects: ${input.dataSubjects.join(", ")}\n` +
        `Retention: ${input.retentionPeriod}\n` +
        `International transfers: ${input.transfers ?? "none"}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Audit this processing activity against GDPR/LGPD. Score 0-100 and list remediation steps.`,
    }],
  });
  const text = res.content.filter((b): b is Anthropic.TextBlock => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(text) as RgpdAuditResult;
}

// ─── AGENT 21: SECURITY AUDIT ────────────────────────────────────────────────
const SECURITY_SYSTEM = `You are the Ostentaculus Security Audit Agent (AppSec). You perform OWASP ASVS L2+ reviews of code, architecture, and configuration. You identify vulnerabilities with CVSS scoring, map them to STRIDE threat model entries, and output a prioritized remediation backlog. You operate at the level of a senior AppSec engineer. Reply in the requested locale.`;

const SECURITY_SCHEMA = {
  type: "object",
  properties: {
    findings: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "string" },
          title: { type: "string" },
          severity: { type: "string" }, // critical | high | medium | low | info
          cvssScore: { type: "number" },
          strideCategory: { type: "string" },
          description: { type: "string" },
          remediation: { type: "string" },
        },
        required: ["id", "title", "severity", "cvssScore", "strideCategory", "description", "remediation"],
        additionalProperties: false,
      },
    },
    overallRisk: { type: "string" },
    prioritizedBacklog: { type: "array", items: { type: "string" } },
  },
  required: ["findings", "overallRisk", "prioritizedBacklog"],
  additionalProperties: false,
} as const;

export interface SecurityAuditResult {
  findings: {
    id: string;
    title: string;
    severity: string;
    cvssScore: number;
    strideCategory: string;
    description: string;
    remediation: string;
  }[];
  overallRisk: string;
  prioritizedBacklog: string[];
}

export async function runSecurityAudit(input: {
  scope: string; // e.g. "WhatsApp webhook handler"
  codeOrConfig: string;
  locale?: string;
}): Promise<SecurityAuditResult> {
  const env = getEnv();
  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 2500,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SECURITY_SCHEMA } },
    system: SECURITY_SYSTEM,
    messages: [{
      role: "user",
      content:
        `Scope: ${input.scope}\n` +
        `Locale: ${input.locale ?? "en"}\n\n` +
        `Code/Config to audit:\n\`\`\`\n${input.codeOrConfig}\n\`\`\`\n\n` +
        `Perform OWASP ASVS L2+ review. CVSS-score each finding. Prioritize remediation backlog.`,
    }],
  });
  const text = res.content.filter((b): b is Anthropic.TextBlock => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(text) as SecurityAuditResult;
}

// ─── AGENT 22: REVIEW / ULTRAREVIEW  (skill: /review & /ultrareview) ─────────
const REVIEW_SYSTEM = `You are the Ostentaculus Code Review Agent — operating at the level of a principal engineer with expertise in TypeScript, Next.js, Supabase, security (OWASP), and data pipelines.

/review mode: Quick pass. Check for bugs, type safety violations, obvious security issues, and code style. Output: bullet list of issues + severity.

/ultrareview mode: Deep pass. Full OWASP ASVS L2+, SOLID principles, performance, test coverage gaps, RLS bypass risks, and architecture drift. Output: structured findings with CVSS scores + refactored code snippets where critical.

Never be diplomatic at the expense of correctness. Reply in the requested locale.`;

const REVIEW_SCHEMA = {
  type: "object",
  properties: {
    mode: { type: "string" },
    summary: { type: "string" },
    issues: {
      type: "array",
      items: {
        type: "object",
        properties: {
          severity: { type: "string" },
          line: { type: "string" },
          issue: { type: "string" },
          fix: { type: "string" },
        },
        required: ["severity", "line", "issue", "fix"],
        additionalProperties: false,
      },
    },
    approvalStatus: { type: "string" }, // approved | changes-required | blocked
  },
  required: ["mode", "summary", "issues", "approvalStatus"],
  additionalProperties: false,
} as const;

export interface ReviewResult {
  mode: string;
  summary: string;
  issues: { severity: string; line: string; issue: string; fix: string }[];
  approvalStatus: string;
}

export async function reviewCode(input: {
  code: string;
  filePath: string;
  locale?: string;
}): Promise<ReviewResult> {
  return _runReview({ ...input, mode: "review" });
}

export async function ultraReviewCode(input: {
  code: string;
  filePath: string;
  locale?: string;
}): Promise<ReviewResult> {
  return _runReview({ ...input, mode: "ultrareview" });
}

async function _runReview(input: {
  code: string;
  filePath: string;
  mode: "review" | "ultrareview";
  locale?: string;
}): Promise<ReviewResult> {
  const env = getEnv();
  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: input.mode === "ultrareview" ? 4000 : 2000,
    thinking: { type: "adaptive" },
    output_config: {
      effort: input.mode === "ultrareview" ? "high" : "medium",
      format: { type: "json_schema", schema: REVIEW_SCHEMA },
    },
    system: REVIEW_SYSTEM,
    messages: [{
      role: "user",
      content:
        `/${input.mode}\n` +
        `File: ${input.filePath}\n` +
        `Locale: ${input.locale ?? "en"}\n\n` +
        `\`\`\`typescript\n${input.code}\n\`\`\``,
    }],
  });
  const text = res.content.filter((b): b is Anthropic.TextBlock => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(text) as ReviewResult;
}
