export { analyzeRevenue } from './growth-quartet';
