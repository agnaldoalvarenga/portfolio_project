import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

const SYSTEM = `You are the Ostentaculus cinematic scriptwriter — a documentary auteur who writes in the tradition of Maysles Brothers, Errol Morris, and Werner Herzog, applied to food & hospitality businesses in the Iberian Peninsula and LATAM.

Structure EVERY script in the classic 3-act dramatic arc:
  ACT 1 — WORLD AS IT WAS: introduce the protagonist and their craft before the turning point.
  ACT 2 — THE CRUCIBLE: the challenge, the daily ritual, the obsession, the almost-failure.
  ACT 3 — THE TRANSFORMATION: the resolution — not a happy commercial, a human truth.

Rules:
- The establishment is NEVER the hero. The PERSON behind it is.
- Each scene must stimulate at least 2 senses (visual + olfactory/auditory/tactile).
- Zero corporate language, zero "passion for excellence", zero clichés.
- Include specific director's notes for the Sony FX3 (focal length, movement, light).
- Reply in the requested locale.`;

const SCHEMA = {
  type: "object",
  properties: {
    logline: { type: "string" },
    act1: { type: "string" },
    act2: { type: "string" },
    act3: { type: "string" },
    directorNotes: { type: "array", items: { type: "string" } },
    estimatedDuration: { type: "string" },
  },
  required: ["logline", "act1", "act2", "act3", "directorNotes", "estimatedDuration"],
  additionalProperties: false,
} as const;

export interface CinematicScript {
  logline: string;
  act1: string;
  act2: string;
  act3: string;
  directorNotes: string[];
  estimatedDuration: string;
}

export async function generateCinematicScript(input: {
  protagonistName: string;
  establishmentName: string;
  category: string;
  city: string;
  audienceSignals?: string;
  locale?: string;
}): Promise<CinematicScript> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 3000,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Protagonist: ${input.protagonistName}\n` +
        `Establishment: ${input.establishmentName} (${input.category})\n` +
        `City: ${input.city}\n` +
        `Locale: ${input.locale ?? "es"}\n` +
        `Audience signals: ${input.audienceSignals ?? "(none)"}\n\n` +
        `Write a full 3-act cinematic documentary script. Be specific, sensory, and human.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return JSON.parse(text) as CinematicScript;
}
