import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

/**
 * SKILL: playwright-mcp + playwright-cli
 * Generates Playwright test suites and browser automation scripts for:
 * 1. E2E testing of Ostentaculus flows (onboarding, dashboard, checkout)
 * 2. Data collection from public tourism sources (INE, FRONTUR, Hosteltur)
 * 3. Visual regression testing for the cinema dark design system
 *
 * CLI usage: npx playwright test --config=playwright.config.ts
 * MCP usage: via Playwright MCP server for agent-driven browser control
 */

const client = new Anthropic();

const SYSTEM = `You are the Ostentaculus Playwright Agent. You write production-quality Playwright test suites and browser automation scripts for a Next.js + Supabase + Stripe application.

Test architecture:
- Use Page Object Model (POM) pattern
- Fixtures for auth state (tourist / staff / admin / establishment_owner)
- Separate test files per feature (auth, dashboard, concierge, billing, onboarding)
- Visual snapshots for design system regression
- API mocking via route.fulfill() for external services (Stripe, WhatsApp, Maps)
- Parallel execution with worker isolation
- Accessibility checks via axe-playwright

For data automation scripts:
- Respectful crawling: 1-2 second delays, robots.txt compliance
- Structured output: JSON → Supabase ingest format
- Error recovery: retry with exponential backoff

Output: complete .spec.ts or automation .ts file, ready to run.`;

const SCHEMA = {
  type: "object",
  properties: {
    fileName: { type: "string" },
    type: { type: "string" }, // e2e-test | automation | visual-regression
    code: { type: "string" },
    setupInstructions: { type: "string" },
    runCommand: { type: "string" },
  },
  required: ["fileName", "type", "code", "setupInstructions", "runCommand"],
  additionalProperties: false,
} as const;

export interface PlaywrightScript {
  fileName: string;
  type: string;
  code: string;
  setupInstructions: string;
  runCommand: string;
}

export async function generatePlaywrightScript(input: {
  feature: string; // what to test/automate
  userRole?: string; // tourist | staff | admin | establishment_owner
  flowDescription?: string;
  targetUrl?: string;
  locale?: string;
}): Promise<PlaywrightScript> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 3500,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Feature to test/automate: ${input.feature}\n` +
        `User role: ${input.userRole ?? "establishment_owner"}\n` +
        `Flow: ${input.flowDescription ?? "(infer from feature)"}\n` +
        `Target URL: ${input.targetUrl ?? "http://localhost:3000"}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Generate a complete Playwright script using Page Object Model. Include auth fixtures, API mocks for external services, and accessibility checks.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return JSON.parse(text) as PlaywrightScript;
}

/**
 * Generates the Playwright config file for the Ostentaculus monorepo.
 */
export function generatePlaywrightConfig(): string {
  return `import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [['html'], ['json', { outputFile: 'playwright-report/results.json' }]],
  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'Mobile Safari', use: { ...devices['iPhone 13'] } },
    { name: 'Mobile Chrome', use: { ...devices['Pixel 5'] } },
  ],
  webServer: {
    command: 'pnpm --filter @ostentaculus/web dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});
`;
}
