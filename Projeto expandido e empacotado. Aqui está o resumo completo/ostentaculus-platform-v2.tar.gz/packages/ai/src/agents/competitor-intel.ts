import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

const SYSTEM = `You are the Ostentaculus Competitor Intelligence Agent. You analyze competing hospitality marketing agencies (MMGY Global, Madison Melle, Hawkins International, zö Agency, Contágio Comunicação) and any new entrants. For each competitor, map their strategic weakness and produce the exact counter-positioning statement Ostentaculus should use. You are not a diplomat — be precise and surgical. Reply in the requested locale.`;

const SCHEMA = {
  type: "object",
  properties: {
    competitors: {
      type: "array",
      items: {
        type: "object",
        properties: {
          name: { type: "string" },
          model: { type: "string" },
          weakness: { type: "string" },
          ostentaculusCounter: { type: "string" },
          threatLevel: { type: "string" }, // low | medium | high
        },
        required: ["name", "model", "weakness", "ostentaculusCounter", "threatLevel"],
        additionalProperties: false,
      },
    },
    marketGap: { type: "string" },
    positioningStatement: { type: "string" },
    strategicRecommendation: { type: "string" },
  },
  required: ["competitors", "marketGap", "positioningStatement", "strategicRecommendation"],
  additionalProperties: false,
} as const;

export interface CompetitorIntelligence {
  competitors: {
    name: string;
    model: string;
    weakness: string;
    ostentaculusCounter: string;
    threatLevel: string;
  }[];
  marketGap: string;
  positioningStatement: string;
  strategicRecommendation: string;
}

export async function analyzeCompetitors(input: {
  market: string; // "Spain" | "Portugal" | "LATAM" | "global"
  recentIntelligence?: string; // scraped or manually observed data
  locale?: string;
}): Promise<CompetitorIntelligence> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 2000,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Market: ${input.market}\n` +
        `Locale: ${input.locale ?? "es"}\n` +
        `Recent intelligence: ${input.recentIntelligence ?? "(none)"}\n\n` +
        `Analyze MMGY Global, Madison Melle, Hawkins International, zö Agency, Contágio Comunicação. ` +
        `Map each competitor's weakness and produce Ostentaculus counter-positioning statements.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return JSON.parse(text) as CompetitorIntelligence;
}
