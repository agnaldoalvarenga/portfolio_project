import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

// ─── AGENT 07: TRAFFIC ──────────────────────────────────────────────────────
const TRAFFIC_SYSTEM = `You are the Ostentaculus Traffic Agent. Your single mandate: find and attract the ideal client (independent café/bakery/hotel owners in Spain, Portugal, LATAM) on digital platforms. You design paid+organic traffic strategies that feed the sales funnel. Output platform-specific content briefs, ad copy variants, and targeting parameters. Never recommend broad spray-and-pray campaigns — surgical precision only. Reply in the requested locale.`;

const TRAFFIC_SCHEMA = {
  type: "object",
  properties: {
    platforms: { type: "array", items: { type: "string" } },
    organicStrategy: { type: "string" },
    paidCampaigns: {
      type: "array",
      items: {
        type: "object",
        properties: {
          platform: { type: "string" },
          objective: { type: "string" },
          audience: { type: "string" },
          adCopy: { type: "string" },
          budget: { type: "string" },
        },
        required: ["platform", "objective", "audience", "adCopy", "budget"],
        additionalProperties: false,
      },
    },
    weeklyActions: { type: "array", items: { type: "string" } },
  },
  required: ["platforms", "organicStrategy", "paidCampaigns", "weeklyActions"],
  additionalProperties: false,
} as const;

export interface TrafficPlan {
  platforms: string[];
  organicStrategy: string;
  paidCampaigns: {
    platform: string;
    objective: string;
    audience: string;
    adCopy: string;
    budget: string;
  }[];
  weeklyActions: string[];
}

export async function planTrafficCampaign(input: {
  serviceToPromote: string;
  targetMarket: string;
  monthlyBudgetEur: number;
  locale?: string;
}): Promise<TrafficPlan> {
  const env = getEnv();
  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 1800,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: TRAFFIC_SCHEMA } },
    system: TRAFFIC_SYSTEM,
    messages: [{
      role: "user",
      content:
        `Service: ${input.serviceToPromote}\n` +
        `Target market: ${input.targetMarket}\n` +
        `Monthly budget: €${input.monthlyBudgetEur}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Design a surgical traffic acquisition plan.`,
    }],
  });
  const text = res.content.filter((b): b is Anthropic.TextBlock => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(text) as TrafficPlan;
}

// ─── AGENT 08: SALES ────────────────────────────────────────────────────────
const SALES_SYSTEM = `You are the Ostentaculus Sales Agent. You present the agency's offer (Starter €990/mo | Growth €2,490/mo | Scale €4,990/mo + 20% performance fee) with authority and precision. You handle objections, conduct follow-ups, and close B2B deals with café/bakery/hotel owners. You use the SPIN selling technique and consultative approach — never pressure tactics. You speak the owner's language: revenue, occupancy, ticket average. Reply in the requested locale.`;

const SALES_SCHEMA = {
  type: "object",
  properties: {
    followUpMessage: { type: "string" },
    objectionHandled: { type: "string" },
    proposedTier: { type: "string" },
    nextStep: { type: "string" },
    closingSequence: { type: "array", items: { type: "string" } },
  },
  required: ["followUpMessage", "objectionHandled", "proposedTier", "nextStep", "closingSequence"],
  additionalProperties: false,
} as const;

export interface SalesFollowUp {
  followUpMessage: string;
  objectionHandled: string;
  proposedTier: string;
  nextStep: string;
  closingSequence: string[];
}

export async function runSalesFollowUp(input: {
  prospectName: string;
  establishmentType: string;
  lastInteraction: string;
  objection?: string;
  locale?: string;
}): Promise<SalesFollowUp> {
  const env = getEnv();
  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 1500,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SALES_SCHEMA } },
    system: SALES_SYSTEM,
    messages: [{
      role: "user",
      content:
        `Prospect: ${input.prospectName} (${input.establishmentType})\n` +
        `Last interaction: ${input.lastInteraction}\n` +
        `Objection raised: ${input.objection ?? "(none)"}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Generate a consultative follow-up that moves this deal forward.`,
    }],
  });
  const text = res.content.filter((b): b is Anthropic.TextBlock => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(text) as SalesFollowUp;
}

// ─── AGENT 09: CONVERSION ────────────────────────────────────────────────────
const CONVERSION_SYSTEM = `You are the Ostentaculus Conversion Agent. You optimize landing pages, funnel structures, and micro-conversion triggers in real time. You analyze page copy, CTA placement, social proof elements, and friction points. You apply Cialdini's influence principles, neuromarketing UX patterns, and CRO best practices. Output specific, actionable changes — not vague suggestions. Reply in the requested locale.`;

const CONVERSION_SCHEMA = {
  type: "object",
  properties: {
    frictionPoints: { type: "array", items: { type: "string" } },
    ctaOptimizations: { type: "array", items: { type: "string" } },
    socialProofElements: { type: "array", items: { type: "string" } },
    headlineSuggestions: { type: "array", items: { type: "string" } },
    estimatedConversionLift: { type: "string" },
  },
  required: ["frictionPoints", "ctaOptimizations", "socialProofElements", "headlineSuggestions", "estimatedConversionLift"],
  additionalProperties: false,
} as const;

export interface ConversionOptimization {
  frictionPoints: string[];
  ctaOptimizations: string[];
  socialProofElements: string[];
  headlineSuggestions: string[];
  estimatedConversionLift: string;
}

export async function optimizeConversionPage(input: {
  pageType: string; // landing | pricing | onboarding | checkout
  currentCopy: string;
  conversionGoal: string;
  locale?: string;
}): Promise<ConversionOptimization> {
  const env = getEnv();
  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 1800,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: CONVERSION_SCHEMA } },
    system: CONVERSION_SYSTEM,
    messages: [{
      role: "user",
      content:
        `Page type: ${input.pageType}\n` +
        `Conversion goal: ${input.conversionGoal}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Current page copy:\n${input.currentCopy}\n\n` +
        `Identify friction and output specific optimizations.`,
    }],
  });
  const text = res.content.filter((b): b is Anthropic.TextBlock => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(text) as ConversionOptimization;
}

// ─── AGENT 10: REVENUE ───────────────────────────────────────────────────────
const REVENUE_SYSTEM = `You are the Ostentaculus Revenue Agent. You monitor MRR, churn, LTV, CAC, upsell opportunities, and billing health across all client subscriptions. You identify clients ready for tier upgrades and flag churn risk. You generate revenue optimization reports and upsell scripts. You speak in hard numbers — no fluff. Reply in the requested locale.`;

const REVENUE_SCHEMA = {
  type: "object",
  properties: {
    mrr: { type: "number" },
    churnRisk: { type: "array", items: { type: "string" } },
    upsellOpportunities: { type: "array", items: { type: "string" } },
    revenueActions: { type: "array", items: { type: "string" } },
    forecastNote: { type: "string" },
  },
  required: ["mrr", "churnRisk", "upsellOpportunities", "revenueActions", "forecastNote"],
  additionalProperties: false,
} as const;

export interface RevenueAnalysis {
  mrr: number;
  churnRisk: string[];
  upsellOpportunities: string[];
  revenueActions: string[];
  forecastNote: string;
}

export async function analyzeRevenue(input: {
  subscriptions: { clientName: string; tier: string; mrr: number; lastLogin: string; npsScore?: number }[];
  locale?: string;
}): Promise<RevenueAnalysis> {
  const env = getEnv();
  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 1500,
    thinking: { type: "adaptive" },
    output_config: { effort: "medium", format: { type: "json_schema", schema: REVENUE_SCHEMA } },
    system: REVENUE_SYSTEM,
    messages: [{
      role: "user",
      content:
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Current subscriptions:\n${JSON.stringify(input.subscriptions, null, 2)}\n\n` +
        `Analyze revenue health and output specific actions.`,
    }],
  });
  const text = res.content.filter((b): b is Anthropic.TextBlock => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(text) as RevenueAnalysis;
}
