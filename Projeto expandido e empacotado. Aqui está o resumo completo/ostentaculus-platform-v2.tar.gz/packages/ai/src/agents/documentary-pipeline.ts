import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

const SYSTEM = `You are the Ostentaculus Documentary Pipeline Agent. You manage the production lifecycle of cinematic documentary mini-films: Research → Pre-Production → Shoot → Post-Production → Published. For each stage, you generate shot lists, interview questions, post-production briefs, and YouTube/platform publish checklists. You operate with a Sony FX3 run-and-gun mindset: lean, fast, cinematic. Reply in the requested locale.`;

const SCHEMA = {
  type: "object",
  properties: {
    currentStage: { type: "string" },
    nextActions: { type: "array", items: { type: "string" } },
    shotList: { type: "array", items: { type: "string" } },
    interviewQuestions: { type: "array", items: { type: "string" } },
    postProductionBrief: { type: "string" },
    publishChecklist: { type: "array", items: { type: "string" } },
    estimatedCompletionDays: { type: "number" },
  },
  required: ["currentStage", "nextActions", "shotList", "interviewQuestions", "postProductionBrief", "publishChecklist", "estimatedCompletionDays"],
  additionalProperties: false,
} as const;

export interface DocumentaryPipelineResult {
  currentStage: string;
  nextActions: string[];
  shotList: string[];
  interviewQuestions: string[];
  postProductionBrief: string;
  publishChecklist: string[];
  estimatedCompletionDays: number;
}

export async function generateDocumentaryPipeline(input: {
  establishmentName: string;
  protagonistName: string;
  currentStage: "research" | "shoot" | "edit" | "published";
  context?: string;
  locale?: string;
}): Promise<DocumentaryPipelineResult> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 2000,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Establishment: ${input.establishmentName}\n` +
        `Protagonist: ${input.protagonistName}\n` +
        `Current pipeline stage: ${input.currentStage}\n` +
        `Context: ${input.context ?? "(none)"}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Generate the complete pipeline brief for this stage and prepare the next stage.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return JSON.parse(text) as DocumentaryPipelineResult;
}
