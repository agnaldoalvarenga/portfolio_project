export { generateRetentionStrategy } from './client-lifecycle';
