import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

const client = new Anthropic();

const SYSTEM = `You are the Ostentaculus Neuro-Hook Agent — a specialist in applied neuromarketing, consumer psychology, and sensory stimulation for food & tourism content.

Your expertise:
- Priming Theory: prime the viewer's brain with sensory words before the visual cut.
- ASMR-calibrated audio cues: describe sounds that trigger salivation and comfort.
- Color psychology for appetite (warm ambers, deep burgundies — never clinical whites).
- Scarcity + Social Proof micro-triggers (without fake urgency).
- Pattern interrupt: the opening 3 seconds must break the scroll reflex.
- Mirror neurons: write descriptions that make the audience FEEL the texture, heat, smell.

Output: 5 neuro-engineered hook variants for the first 30 seconds of a video, with the psychological mechanism labeled for each. Include 2 ASMR audio cue suggestions per hook. Reply in the requested locale.`;

const SCHEMA = {
  type: "object",
  properties: {
    hooks: {
      type: "array",
      items: {
        type: "object",
        properties: {
          variant: { type: "string" },
          script: { type: "string" },
          mechanism: { type: "string" },
          asmrCues: { type: "array", items: { type: "string" } },
          colorPalette: { type: "string" },
        },
        required: ["variant", "script", "mechanism", "asmrCues", "colorPalette"],
        additionalProperties: false,
      },
    },
  },
  required: ["hooks"],
  additionalProperties: false,
} as const;

export interface NeuroHook {
  variant: string;
  script: string;
  mechanism: string;
  asmrCues: string[];
  colorPalette: string;
}

export async function generateNeuroHook(input: {
  topic: string;
  category: string; // cafeteria | bakery | hotel | restaurant
  targetEmotion: string; // nostalgia | discovery | comfort | luxury
  locale?: string;
}): Promise<NeuroHook[]> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: 2000,
    thinking: { type: "adaptive" },
    output_config: { effort: "high", format: { type: "json_schema", schema: SCHEMA } },
    system: SYSTEM,
    messages: [{
      role: "user",
      content:
        `Topic: ${input.topic}\n` +
        `Category: ${input.category}\n` +
        `Target emotion to trigger: ${input.targetEmotion}\n` +
        `Locale: ${input.locale ?? "es"}\n\n` +
        `Generate 5 neuro-engineered hook variants. Label the psychological mechanism.`,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return (JSON.parse(text) as { hooks: NeuroHook[] }).hooks;
}
