import Anthropic from "@anthropic-ai/sdk";
import { getEnv } from "@ostentaculus/security/env";

/**
 * SKILL: superpowers
 * Activates "superpower mode" on any agent — forces maximum depth, extended
 * thinking, and adversarial self-critique before finalizing output.
 * Inspired by: Claude extended thinking + adversarial prompting patterns.
 */

const client = new Anthropic();

const SUPERPOWER_PREFIX = `SUPERPOWER MODE ACTIVATED.

Before producing your output:
1. Think deeply for at least 3 minutes of reasoning.
2. List the top 3 ways your initial answer could be wrong or incomplete.
3. Challenge your own assumptions.
4. Only then produce the final output — which must be materially better than your first instinct.

This is not a test. This is real production output for a revenue-generating business.`;

export interface SuperpowerOptions {
  basePrompt: string;
  agentSystem: string;
  maxTokens?: number;
  locale?: string;
}

/**
 * Wraps any agent call with extended thinking + adversarial self-critique.
 * Use when accuracy matters more than speed (e.g. performance fee calculation,
 * security audit, competitor intelligence).
 */
export async function withSuperpowers(input: SuperpowerOptions): Promise<string> {
  const env = getEnv();

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: input.maxTokens ?? 4000,
    thinking: { type: "enabled", budget_tokens: 8000 },
    output_config: { effort: "high" },
    system: `${SUPERPOWER_PREFIX}\n\n${input.agentSystem}`,
    messages: [{
      role: "user",
      content: input.basePrompt,
    }],
  });

  return res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("")
    .trim();
}

/**
 * Superpower variant: adversarial red-team pass.
 * Forces the model to argue AGAINST its own output before finalizing.
 */
export async function withAdversarialSuperpowers(input: SuperpowerOptions): Promise<{
  initialAnswer: string;
  adversarialCritique: string;
  finalAnswer: string;
}> {
  const env = getEnv();

  const schema = {
    type: "object",
    properties: {
      initialAnswer: { type: "string" },
      adversarialCritique: { type: "string" },
      finalAnswer: { type: "string" },
    },
    required: ["initialAnswer", "adversarialCritique", "finalAnswer"],
    additionalProperties: false,
  } as const;

  const res = await client.messages.create({
    model: env.CLAUDE_MODEL,
    max_tokens: input.maxTokens ?? 5000,
    thinking: { type: "enabled", budget_tokens: 10000 },
    output_config: { effort: "high", format: { type: "json_schema", schema } },
    system: `${SUPERPOWER_PREFIX}\n\nAfter your initial answer, play devil's advocate: argue why you are wrong. Then produce a final answer that addresses those critiques.\n\n${input.agentSystem}`,
    messages: [{
      role: "user",
      content: input.basePrompt,
    }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  return JSON.parse(text) as { initialAnswer: string; adversarialCritique: string; finalAnswer: string };
}
